# spam-wa

## install [ termux ]

```
$ pkg install nodejs && git
$ git clone https://github.com/ibnusyawall/spam-wa
$ npm i
$ node index
```

## Description
```
input Delay in seconds
input Number phone
example : 
  - Nomor : 0822******
  - Delay : 12
    -- delay : 12seconds
```
